PRDA S&T Android WebView 앱 빌드 프로젝트

대상 홈페이지: https://juhseo-dev.github.io/PRDA-ST-PORTAL/
앱 ID: kr.co.seotech.prdast
Android 최소 버전: 8.0 (API 26)

기능: 홈페이지 전용 앱 화면, 웹 localStorage, JSON 백업 다운로드 보조,
파일 선택을 통한 JSON 복원, 일반 다운로드, 외부 링크 브라우저 열기.

APK 제작:
1. Android Studio에서 이 폴더를 프로젝트로 엽니다.
2. Gradle Sync 완료를 기다립니다.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. app/build/outputs/apk/debug/app-debug.apk를 휴대폰으로 옮겨 설치합니다.

또는 GitHub에 프로젝트를 업로드하고 Actions > Build PRDA S&T APK를 실행하여
artifact에서 APK를 받을 수 있습니다.

주의:
- APK는 현재 이 환경에서 컴파일/검증되지 않았습니다.
- 설치 후 JSON 백업, 복원, PDF 다운로드 등 기능을 실기기에서 점검하세요.
- 웹사이트와 별도 V10 앱의 코드나 저장 데이터는 변경하지 않습니다.
- 디버그 APK는 테스트용 서명입니다. 정식 배포에는 릴리스 서명이 필요합니다.
