package kr.co.seotech.prdast;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;

import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.os.Build;
import android.util.Base64;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final String HOME = "https://juhseo-dev.github.io/PRDA-ST-PORTAL/";
    private WebView web;
    private FrameLayout appRoot;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICK = 421;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        appRoot = new FrameLayout(this);
        web = new WebView(this);
        appRoot.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(appRoot);
        showStartupSplash();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equalsIgnoreCase(uri.getScheme()) && "juhseo-dev.github.io".equalsIgnoreCase(uri.getHost()) && uri.getPath() != null && uri.getPath().startsWith("/PRDA-ST-PORTAL/")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception e) { Toast.makeText(MainActivity.this,"링크를 열 수 없습니다",Toast.LENGTH_SHORT).show(); }
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (url.startsWith(HOME)) installBlobDownloadHook();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try { startActivityForResult(params.createIntent(), FILE_PICK); return true; }
                catch (Exception e) { fileCallback = null; Toast.makeText(MainActivity.this,"파일 선택 불가",Toast.LENGTH_SHORT).show(); return false; }
            }
        });
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void saveBlob(String base64, String filename, String mime) {
                try {
                    byte[] data = Base64.decode(base64, Base64.DEFAULT);
                    String safe = filename == null ? "PRDA_ST_backup.json" : filename.replaceAll("[^a-zA-Z0-9가-힣._-]", "_");
                    if (safe.length() == 0) safe = "PRDA_ST_backup.json";
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                        v.put(MediaStore.Downloads.MIME_TYPE, mime == null || mime.isEmpty() ? "application/json" : mime);
                        v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/");
                        Uri target = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                        if (target == null) throw new Exception("download uri unavailable");
                        try (OutputStream out = getContentResolver().openOutputStream(target)) { if (out == null) throw new Exception("output unavailable"); out.write(data); }
                    } else {
                        java.io.File file = new java.io.File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), safe);
                        try (OutputStream out = new java.io.FileOutputStream(file)) { out.write(data); }
                    }
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "다운로드 폴더에 저장했습니다", Toast.LENGTH_LONG).show());
                } catch (Exception e) { runOnUiThread(() -> Toast.makeText(MainActivity.this,"백업 저장 실패: " + e.getMessage(),Toast.LENGTH_LONG).show()); }
            }
        }, "PRDAAndroid");
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url.startsWith("blob:")) { installBlobDownloadHook(); return; }
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.addRequestHeader("User-Agent", userAgent);
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, android.webkit.URLUtil.guessFileName(url,contentDisposition,mimeType));
                ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
                Toast.makeText(this,"다운로드를 시작했습니다",Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this,"다운로드 실패",Toast.LENGTH_SHORT).show(); }
        });
        if (savedInstanceState != null) web.restoreState(savedInstanceState); else web.loadUrl(HOME);
    }

    // 2-second branded opening screen; the website loads underneath it.
    private void showStartupSplash() {
        getWindow().setStatusBarColor(Color.rgb(5, 24, 46));
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setPadding(dp(28), dp(20), dp(28), dp(20));
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(5, 22, 45), Color.rgb(12, 57, 99), Color.rgb(3, 18, 40)});
        splash.setBackground(bg);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.splash_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(224), dp(224));
        logoLp.bottomMargin = dp(26);
        splash.addView(logo, logoLp);

        TextView subtitle = new TextView(this);
        subtitle.setText("정압설비 통합 플랫폼");
        subtitle.setTextColor(Color.WHITE);
        subtitle.setTextSize(22);
        subtitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        subtitle.setGravity(Gravity.CENTER);
        splash.addView(subtitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView slogan = new TextView(this);
        slogan.setText("현장에서 답을 찾고,\n기술을 전하고 기록으로 남긴다.");
        slogan.setTextColor(Color.rgb(199, 220, 239));
        slogan.setTextSize(13);
        slogan.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sloganLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sloganLp.topMargin = dp(24);
        splash.addView(slogan, sloganLp);

        appRoot.addView(splash, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!isFinishing() && splash.getParent() == appRoot) {
                appRoot.removeView(splash);
            }
        }, 2000);
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void installBlobDownloadHook() {
        String js = "(function(){if(window.__prdaBlobHook)return;window.__prdaBlobHook=true;document.addEventListener('click',function(e){var a=e.target.closest('a[download]');if(!a||!a.href.startsWith('blob:'))return;e.preventDefault();e.stopImmediatePropagation();fetch(a.href).then(r=>r.blob()).then(b=>{var fr=new FileReader();fr.onloadend=function(){PRDAAndroid.saveBlob(fr.result.split(',')[1],a.download||'PRDA_ST_backup.json',b.type||'application/json')};fr.readAsDataURL(b)}).catch(()=>{});},true)})();";
        web.evaluateJavascript(js, null);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == FILE_PICK && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));
            fileCallback = null;
        }
    }
    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onSaveInstanceState(Bundle outState) { web.saveState(outState); super.onSaveInstanceState(outState); }
    @Override protected void onDestroy() { web.destroy(); super.onDestroy(); }
}
